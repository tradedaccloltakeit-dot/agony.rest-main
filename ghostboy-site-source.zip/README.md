# ghostboy.net public page mirror

**Downloaded:** 2026-11-13 (UTC)  
**Source:** https://ghostboy.net/

This is a mirror of the publicly reachable page. The site is a single HTML
document with no separate JavaScript files, no sitemap, and no robots.txt.

## Files

| Path | What it is |
|---|---|
| `ghostboy.net/index.html` | The page with its stylesheet rewritten to local fonts |
| `ghostboy.net/index-original.html` | The exact fetched HTML, including the original Google Fonts link |
| `ghostboy.net/assets/fonts.css` | Localized JetBrains Mono `@font-face` rules |
| `ghostboy.net/assets/fonts/*.woff2` | Six unique WOFF2 font files used by 24 font-face rules |
| `fonts.googleapis.com/jetbrains-mono-original.css` | Original Google Fonts CSS response |
| `fonts.gstatic.com/...` | Original downloaded font files, kept as source artifacts |
| `fonts.googleapis.com/robots.txt` | The font host's robots file, not site content |

The page itself is about **2.85 MB**, mostly because its audio track is embedded
inline as a base64 `data:audio/mpeg` URI. That audio is part of `index.html`;
there is no separate media file. The favicon is an inline SVG data URI.

## Scope

- One public page. There are no internal page links beyond `#` and a mailto link.
- External links to Instagram, Steam, Telegram, and TikTok are preserved but not
  mirrored; they are separate services, not ghostboy.net content.
- No login, account, API, or server-side source is present in the downloaded page.
- Separate checks of `robots.txt` and `sitemap.xml` returned 404. During the
  crawl, `wget` also probed the Google Fonts host roots, which returned 404;
  those are not page assets. It exited with status 8 because of those probes,
  but the page and all six unique font files were saved successfully.

## View it locally

From the extracted archive root:

```bash
cd ghostboy.net
python3 -m http.server 8000
```

Open <http://localhost:8000/>.

`index.html` uses the local font stylesheet, so it works offline. The original
HTML is kept as `index-original.html` if you want to compare the source exactly.

## Note

The design, text, audio, and other content belong to the site owner. Keep this
archive for inspection and do not republish the content without permission.
